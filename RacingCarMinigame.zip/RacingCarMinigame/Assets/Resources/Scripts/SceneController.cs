﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SceneController : MonoBehaviour {

	List<GameObject>fila1 = new List<GameObject>();
	List<GameObject>fila2 = new List<GameObject>();
	List<GameObject>fila3 = new List<GameObject>();
	List<GameObject>fila4 = new List<GameObject>();
    GameObject car, enemy;
    public Text score;    

    //Se empiezan a generar lineas de la carretera y coches enemigos.
	void Start () {
		InvokeRepeating ("creaLinea",0, .5f);
		InvokeRepeating("enemyGenerator", 1, .5f);
		car = Instantiate (Resources.Load ("Prefabs/formula"), new Vector2 (0, -2.5f), new Quaternion (0, 0, 0, 0)) as GameObject;
        Singleton.score = 0;
	}

	//Comprueba las líneas y actualiza el texto de la puntuación.
	void Update () {
        
		compruebaLinea (fila1);
		compruebaLinea (fila2);
		compruebaLinea (fila3);
		compruebaLinea (fila4);

        score.text = Singleton.score.ToString();
	}

    //Crea una nueva línea en cada fila.
	void creaLinea(){

		fila1.Add(Instantiate (Resources.Load ("Prefabs/white"), new Vector2 (-3 , 4), new Quaternion (0, 0, 0, 0)) as GameObject);
		fila2.Add(Instantiate (Resources.Load ("Prefabs/white"), new Vector2 (-1, 4), new Quaternion (0, 0, 0, 0)) as GameObject);
		fila3.Add(Instantiate (Resources.Load ("Prefabs/white"), new Vector2 (1, 4), new Quaternion (0, 0, 0, 0)) as GameObject);
		fila4.Add(Instantiate (Resources.Load ("Prefabs/white"), new Vector2 (3, 4), new Quaternion (0, 0, 0, 0)) as GameObject);

	}

    //Comprueba la posición de las líneas y destruye las que han salido de pantalla.
	void compruebaLinea(List<GameObject> fila){
		for (int i = 0; i < fila.Count; i++) {
			GameObject linea = fila [i];

			linea.transform.position = new Vector2 (linea.transform.position.x, linea.transform.position.y - 0.2f);

			if (linea.transform.position.y <= -4) {
				Destroy (linea);
				fila.RemoveAt (i);
			}

		}			
	}

    //Genera enemigos de tipo y posición aleatoria
	void enemyGenerator()
	{
		int enemyType = Random.Range(1, 5);
		int enemyPos = Random.Range(-2, 3);
		if (enemyPos != -2 && enemyPos != 2)
		{
			enemyPos = 0;
		}
		switch (enemyType)
		{
		case 1:
			enemy = Instantiate(Resources.Load("Prefabs/truck"), new Vector2(enemyPos, 4), new Quaternion(0, 0, 0, 0)) as GameObject;
			break;
		case 2:
			enemy = Instantiate(Resources.Load("Prefabs/yellowCar"), new Vector2(enemyPos, 4), new Quaternion(0, 0, 0, 0)) as GameObject;
			break;
		case 3:
			enemy = Instantiate(Resources.Load("Prefabs/redCar"), new Vector2(enemyPos, 4), new Quaternion(0, 0, 0, 0)) as GameObject;
			break;
		case 4:
			enemy = Instantiate(Resources.Load("Prefabs/blueCar"), new Vector2(enemyPos, 4), new Quaternion(0, 0, 0, 0)) as GameObject;
			break;

		}
	}
}
