﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyMovement : MonoBehaviour {

    private bool hasGivePoints;
	//Se mueve hacia abajo. Da un punto tras llegar a cierta posición y se destruye tras salir de la pantalla.
	void Update () {
        transform.position = new Vector2(transform.position.x, transform.position.y - 0.15f);
        if(!hasGivePoints && transform.position.y <= -2.3f)
        {
            hasGivePoints = true;
            Singleton.score += 1;
        }
		if (transform.position.y <= -4){
            Destroy(this.gameObject);
        }
    }

   
}
