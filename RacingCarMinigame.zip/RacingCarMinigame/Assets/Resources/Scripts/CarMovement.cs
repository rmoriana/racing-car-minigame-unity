﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class CarMovement : MonoBehaviour {

    bool keyPressed = false;
    public float actualPosition = 0;   

    //Control de inputs.
    void Update () {

		if (Input.GetKeyDown (KeyCode.LeftArrow) && keyPressed == false && actualPosition > -2) {
            actualPosition = transform.position.x;
            InvokeRepeating ("leftMove", 0, 0.02f);
            keyPressed = true;
		}

		if (Input.GetKeyDown (KeyCode.RightArrow) && keyPressed == false && actualPosition < 2) {
            actualPosition = transform.position.x;
            InvokeRepeating ("rightMove", 0, 0.02f);
            keyPressed = true;
        }

	}

    //Movimiento hacia la izquierda.
	void leftMove(){    
        if(actualPosition == 0)
        {            
            transform.position = new Vector2(transform.position.x - 0.2f, transform.position.y);
            if (transform.position.x <= -2)
            {
                transform.position = new Vector2(-2, transform.position.y);
                CancelInvoke("leftMove");
                keyPressed = false;
                actualPosition = transform.position.x;
            }
        }
        else
        {
            transform.position = new Vector2(transform.position.x - 0.2f, transform.position.y);
            if (transform.position.x <= 0)
            {
                transform.position = new Vector2(0, transform.position.y);
                CancelInvoke("leftMove");
                keyPressed = false;
                actualPosition = transform.position.x;
            }
        }
        
	
	}

    //Movimiento hacia la derecha
	void rightMove(){
        if(actualPosition == 0)
        {
            transform.position = new Vector2(transform.position.x + 0.2f, transform.position.y);
            if (transform.position.x >= 2)
            {
                CancelInvoke("rightMove");
                keyPressed = false;
                actualPosition = transform.position.x;
            }
        }
        else
        {
            transform.position = new Vector2(transform.position.x + 0.2f, transform.position.y);
            if (transform.position.x >= -0.2f)
            {
                transform.position = new Vector2(0, transform.position.y);
                CancelInvoke("rightMove");
                keyPressed = false;
                actualPosition = transform.position.x;
            }
        }       	
	}

    //Colision que termina el juego.
    private void OnCollisionEnter2D(Collision2D other)
    {
        if(other.gameObject.tag == "enemy")
        {
            Invoke("GameOver", 1);
        }
    }

    //Carga la escena de GameOver
    private void GameOver()
    {
        SceneManager.LoadScene("GameOver");
    }
}
