﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameOverScore : MonoBehaviour {

    public Text score;

    //Muestra la puntuación final.
	void Start () {
        score.text = "Your score is: "+Singleton.score.ToString();
	}
	
}
